pinta_bloque(MatrizPickGlobal,'b')
pinta_bloque(MatrizPlaceGlobal,'r')
