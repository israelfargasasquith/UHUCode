function D=desplazamiento(x0,y0,z0)
D=[1 0 0 x0 ; 0 1 0 y0 ; 0 0 1 z0; 0 0 0 1];