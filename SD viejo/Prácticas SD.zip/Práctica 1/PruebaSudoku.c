
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[])
{
    printf("Dificultad: \t\t Huecos: ");
    printf("  123 456 789");
    printf("  +---+---+---+");
    printf("1| 0000|0000|0000|");
    printf("2| 0000|0000|0000|");
    printf("3| 0000|0000|0000|");
    printf("  +---+---+---+");
    printf("4| 0000|0000|0000|");
    printf("5| 0000|0000|0000|");
    printf("6| 0000|0000|0000|");
    printf("  +---+---+---+");
    printf("7| 0000|0000|0000|");
    printf("8| 0000|0000|0000|");
    printf("9| 0000|0000|0000|");
    printf("  +---+---+---+");
    printf("**Linea de avisos**\n\n");
    printf("1.- Juego nuevo");
    printf("2.- Borrar juego");
    printf("3.- Poner valor");
    printf("4.- Borrar valor");
    printf("5.- Ayuda");
    printf("6.- Salir");
    printf("Elige opcion: ");
exit(0);
}
