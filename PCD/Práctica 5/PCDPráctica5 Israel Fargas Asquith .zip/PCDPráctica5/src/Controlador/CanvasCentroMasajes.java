/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.ClienteMasaje;
import Modelo.ClienteRehabilita;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import javax.imageio.ImageIO;

/**
 *
 * @author 34667
 */
public class CanvasCentroMasajes extends Canvas {

    private int alto, ancho;
    private boolean masajistaLibre, fisioterapeutaLibre, vestuarioLibre;
    private ArrayList<Thread> lClientes;
    private BufferedImage clienteMasaje, clienteRehabilitacion, masajista, fisio;
    private int nEsperandoMasaje = 0;
    private int nEsperandoFisio = 0;
    private boolean modificamosMasaje = false;
    private boolean modificamosRehabilitacion = false;
    private long idAMover;
    private ArrayList<ClienteMasaje> lMasaje;
    private ArrayList<ClienteRehabilita> lRehabilita;

    public CanvasCentroMasajes(int alto, int ancho, ArrayList<Thread> lClientes) {//, ArrayList<ClienteMasaje> lMasaje, ArrayList<ClienteRehabilita> lRehabilita) {

        this.alto = alto;
        this.ancho = ancho;
        this.lClientes = lClientes;
//        this.lMasaje = lMasaje;
//        this.lRehabilita = this.lRehabilita;
        try {
            clienteMasaje = ImageIO.read(new File("src\\Imagenes\\clienteMasaje.jpg"));
            clienteRehabilitacion = ImageIO.read(new File("src\\Imagenes\\dolorEspalda.jpg"));
            masajista = ImageIO.read(new File("src\\Imagenes\\masaje.jpg"));
            fisio = ImageIO.read(new File("src\\Imagenes\\fisio.jpg"));
        } catch (IOException ex) {
            System.out.println("Error con los archivos: " + ex.getMessage());
        }

        setBackground(Color.LIGHT_GRAY);
        setSize(alto, ancho);
        setVisible(true);
        repaint();
    }

    public void actualiza(boolean masajistaLibre, boolean fisioterapeutaLibre, boolean vestuarioLibre, String nombreClase, long idThread, int nEsperandoMasaje, int nEsperandoFisio) {

        this.masajistaLibre = masajistaLibre;
        this.fisioterapeutaLibre = fisioterapeutaLibre;
        this.vestuarioLibre = vestuarioLibre;
        this.nEsperandoFisio = nEsperandoFisio;
        this.nEsperandoMasaje = nEsperandoMasaje;

        if (nombreClase.equalsIgnoreCase("masaje")) {
            modificamosMasaje = true;
            idAMover = idThread;
        } else if (nombreClase.equalsIgnoreCase("rehabilita")) {
            modificamosRehabilitacion = true;
            idAMover = idThread;
        }
        repaint();
    }

    @Override
    public void paint(Graphics g) {
        Image buffer = createImage(alto, ancho);
        Graphics tmp = buffer.getGraphics();

        Font f1 = new Font("Helvetica", Font.BOLD, 20);
        tmp.setFont(f1);

        tmp.drawString("Cola de Masajes:", 20, 95);
        tmp.drawString("Cola de Fisio:", 20, 600);
        tmp.drawString("Masajista:", 625, 95);
        tmp.drawString("Fisioterapeuta:", 625, 620);
        tmp.drawString("Vestuario:", 850, 295);
        tmp.drawString("Acabados:", 20, 375);

        tmp.setColor(Color.WHITE);
        tmp.fillRect(20, 100, 600, 100); //Cola masajes
        tmp.fillRect(20, 650, 600, 100); //Cola fisio
        tmp.fillRect(625, 100, 200, 125); //Masajista
        tmp.fillRect(625, 625, 200, 125); //Fisio
        tmp.fillRect(850, 300, 250, 250); //Vestuario
        tmp.fillRect(20, 380, 600, 100); //Acabados

        //tmp.drawImage(fisio, 480, 435, 90, 100, this);
        //tmp.drawImage(masajista, 480, 110, 90, 100, this);
        int mover = 90; //pixeles
        int i = nEsperandoMasaje;
        int j = nEsperandoFisio;
        tmp.setColor(Color.black);
        System.out.println("Hay esperando fisio: " + nEsperandoFisio + " esperando masaje: " + nEsperandoMasaje);

        for (Thread lCliente : lClientes) {
            if (lCliente.getClass().equals(ClienteMasaje.class)) {
                tmp.drawImage(clienteMasaje, 25 + (i * mover), 105, 90, 100, this);
                tmp.drawString("" + lCliente.threadId(), 25 + (i * mover), 105);
                i--;
            } else if (lCliente.getClass().equals(ClienteRehabilita.class)) {
                tmp.drawImage(clienteRehabilitacion, 25 + (j * mover), 450, 90, 100, this);
                tmp.drawString("" + lCliente.threadId(), 25 + (j * mover), 405);
                j--;
            }
        }
//        for (ClienteMasaje lmasaje : lMasaje) {
//            tmp.drawImage(clienteMasaje, 25 + (i * mover), 105, 90, 100, this);
//            tmp.drawString("" + lmasaje.threadId(), 25 + (i * mover), 105);
//            i--;
//        }
//
//        for (ClienteRehabilita clienteRehabilita : lRehabilita) {
//            tmp.drawImage(clienteRehabilitacion, 25 + (j * mover), 450, 90, 100, this);
//           // tmp.drawString("" + clienteRehabilita.threadId(), 25 + (j * mover), 405);
//            j--;
//        }

        if (modificamosMasaje) {
            if (masajistaLibre) {
                tmp.drawImage(clienteMasaje, 425, 100, 90, 100, this);
                tmp.drawString("" + idAMover, 425, 100);
            }
            if (fisioterapeutaLibre) {
                tmp.drawImage(clienteMasaje, 425, 425, 90, 100, this);
                tmp.drawString("" + idAMover, 425, 425);
            }
            if (vestuarioLibre) {
                tmp.drawImage(clienteMasaje, 650, 200, 90, 100, this);
                tmp.drawString("" + idAMover, 650, 200);
            }

            modificamosMasaje = false;
        }
        if (modificamosRehabilitacion) {

            if (fisioterapeutaLibre) {
                tmp.drawImage(clienteRehabilitacion, 425, 425, 90, 100, this);
                tmp.drawString("" + idAMover, 425, 425);
            }
            if (vestuarioLibre) {
                tmp.drawImage(clienteRehabilitacion, 650, 200, 90, 100, this);
                tmp.drawString("" + idAMover, 650, 200);
            }

            modificamosRehabilitacion = false;
        }

        tmp.drawImage(buffer, 0, 0, null); //pintamos la imagen de buffer en el frame para evitar parpadeos
        g.drawImage(buffer, 0, 0, null);
    }

    @Override
    public void update(Graphics g) {
        paint(g);
    }

}
