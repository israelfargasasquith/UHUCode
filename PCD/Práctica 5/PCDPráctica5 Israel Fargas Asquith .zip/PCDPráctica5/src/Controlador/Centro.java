/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.ClienteMasaje;
import Modelo.ClienteRehabilita;
import java.util.ArrayList;

/**
 *
 * @author 34667
 */
public class Centro {

    private boolean masajistaLibre = true;
    private boolean fisioterapeutaLibre = true;
    private boolean vestuarioLibre = true;
    private int nEsperandoMasaje = 0;
    private int nEsperandoFisio = 0;
    private CanvasCentroMasajes canvas;
    private ClienteMasaje clm;
    private ClienteRehabilita clr;

    public Centro(CanvasCentroMasajes canvas) {
        this.canvas = canvas;
    }

    synchronized public void setNEsperando(int nEsperandoFisio, int nEsperandoMasaje) {  //creo que no hace falta el synchro
        this.nEsperandoMasaje = nEsperandoMasaje;
        this.nEsperandoFisio = nEsperandoFisio;
    }

    synchronized public void entraMasaje() throws InterruptedException {
        while (!masajistaLibre || (!fisioterapeutaLibre && nEsperandoFisio == 0)) {
            wait();
        }
        nEsperandoMasaje--;
        if (masajistaLibre) {
            masajistaLibre = false;
            System.out.println("Soy hilo " + Thread.currentThread().threadId() + " y acabo de entrar en el masajista");
        }
        if (fisioterapeutaLibre) {
            fisioterapeutaLibre = false;
            System.out.println("Soy hilo " + Thread.currentThread().threadId() + " y acabo de entrar en el fisio pero quiero masaje");
        }
        canvas.actualiza(masajistaLibre, fisioterapeutaLibre, vestuarioLibre, "Masaje", Thread.currentThread().threadId(), nEsperandoMasaje, nEsperandoFisio);
    }

    synchronized public void saleMasaje() throws InterruptedException {
        while (!vestuarioLibre) {
            wait();
        }
        masajistaLibre = true;
        vestuarioLibre = false;
        System.out.println("Soy hilo " + Thread.currentThread().threadId() + " y acabo de entrar en el vestuario");
        canvas.actualiza(masajistaLibre, fisioterapeutaLibre, vestuarioLibre, "Masaje", Thread.currentThread().threadId(), nEsperandoMasaje, nEsperandoFisio);
        notifyAll();
    }

    synchronized public void entraRehabilita() throws InterruptedException {
        while (!fisioterapeutaLibre) {
            wait();
        }
        nEsperandoFisio--;
        fisioterapeutaLibre = false;
        System.out.println("Soy hilo " + Thread.currentThread().threadId() + " y acabo de entrar en el fisio");
        canvas.actualiza(masajistaLibre, fisioterapeutaLibre, vestuarioLibre, "Rehabilita", Thread.currentThread().threadId(), nEsperandoMasaje, nEsperandoFisio);

    }

    synchronized public void saleRehabilita() throws InterruptedException {
        while (!vestuarioLibre) {
            wait();
        }
        fisioterapeutaLibre = true;
        vestuarioLibre = false;
        System.out.println("Soy hilo " + Thread.currentThread().threadId() + " y acabo de entrar en el vestuario");
        canvas.actualiza(masajistaLibre, fisioterapeutaLibre, vestuarioLibre, "Rehabilita", Thread.currentThread().threadId(), nEsperandoMasaje, nEsperandoFisio);
        notifyAll();
    }

    synchronized public void terminaMasaje() {
        vestuarioLibre = true;
        canvas.actualiza(masajistaLibre, fisioterapeutaLibre, vestuarioLibre, "Masaje", Thread.currentThread().threadId(), nEsperandoMasaje, nEsperandoFisio);
        notifyAll();
    }
    
     synchronized public void terminaFisio() {
        vestuarioLibre = true;
        canvas.actualiza(masajistaLibre, fisioterapeutaLibre, vestuarioLibre, "Rehabilita", Thread.currentThread().threadId(), nEsperandoMasaje, nEsperandoFisio);
        notifyAll();
    }

}
